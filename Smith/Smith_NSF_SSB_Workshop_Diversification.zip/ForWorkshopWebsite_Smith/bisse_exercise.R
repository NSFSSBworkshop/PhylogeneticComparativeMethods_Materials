## Code by Stacey D. Smith, June 2015
## NSF-SSB workshop in Model-Based Phylogenetics
## Feel free to download, distribute, edit and change the code as you see fit, however acknowledgment of the authors is expected. 

## install.packages("diversitree", dependencies=TRUE)
library(diversitree)

# read in datafiles, extracted from Magnuson-Ford and Otto, 2012
# http://datadryad.org/resource/doi:10.5061/dryad.2sr417nv

setwd("~/Desktop") #make sure the input files are on the desktop
phy<-read.nexus("primate_tree.nex") # 1st of 100 trees in original dataset
data<-read.csv("primate_states.csv", header=FALSE)

#for input to BiSSE need states as a named vector
# which is currently as a table, enter head(data) to see that
states<-data[,2] #extract just the scoring of 0's and 1's, 0 is diurnal, 1 is nocturnal
names(states)<-data[,1] #attach the taxon names to the states

#let's check out this dataset to see how the states are distributed
plot(phy, label.offset = 0.6, cex=0.3) #may have to fiddle with values to make look good on your screen
col <- c("#eaab00", "#004165") # yellow for diurnal, blue for nocturnal
tiplabels(col=col[states+1], pch=19, adj=0.8, cex=0.5)

# the taxa in the phylogeny exactly match those in the dataset thus we can proceed
# if they did not, you would need to prune the tree with drop.tip or remove rows from the data until they match
# note that taxon names between the two must be IDENTICAL

# first we make BiSSE likelihood function
lik<-make.bisse(phy, states) 
# this is close to a complete phylogeny, but if it were not, and you wanted to use the skeleton tree method
# to account for missing taxa, you would do it here with the sampling.f argument
lik # you can see the six parameters in this model and assumptions, e.g. root state

# in order to estimate the parameters in the model, need a starting point for the likelihood search
start<-starting.point.bisse(phy) #assumes no state-dependent diversification and equal transition rates
start # which you can see by the fact that lambda0=lambda1, mu0=mu1, q01=q10
mle.bisse<-find.mle(lik,start) #searches for the ML parameter values, beginning at the start
mle.bisse # note ML parameter estimates and lnLik

# let's compare with a constrained model without state-dependent diversification
lik.eq.div <- constrain(lik, lambda0 ~ lambda1, mu0~mu1) #note, this is not the only way to get equal div
mle.eq.div <- find.mle(lik.eq.div, start[argnames(lik.eq.div)]) #we restrict the starting point parameter to just the ones in the equal diversification model
mle.eq.div

# formally compare the two models (with and without state-dependent diversification with a likelihood ratio test)
# the chi-squared value is twice the difference in the likelihood scores
# df is the difference in the number of parameters -- 6 rates for bisse, 4 rates for eq.div, therefore df=2

1-pchisq(2*(mle.bisse$lnLik-mle.eq.div$lnLik),df=2)

# we could also test for state-dependent diversification with MCMC Bisse as opposed to an LRT
# do a short run to configure the chain
prior<-make.prior.exponential(1/(2*(start[1]-start[3]))) #exponential prior with rates = 1/2*r, the diversification rate, which is lambda - mu
temp<-mcmc(lik,mle.bisse$par,nsteps=100, prior, lower=0, w=rep(1,6)) #just 100 steps of "width" (w) = 1
neww<-diff(sapply(temp[2:7],range)) #reset the width base on the range of parameter values from this short run
 
mcmc.bisse<-mcmc(lik,mle.bisse$par,nsteps=100, prior, lower=0, w=neww) #100 just for example, you'd want to do many more 
# extract diversification rates, r0 and r1 from this and plot
mcmc.bisse[,9]<-mcmc.bisse$lambda0-mcmc.bisse$mu0
mcmc.bisse[,10]<-mcmc.bisse$lambda1-mcmc.bisse$mu1
colnames(mcmc.bisse)[9]<-"r0, diurnal diversification rate"
colnames(mcmc.bisse)[10]<-"r1, nocturnal diversification rate"
profiles.plot(mcmc.bisse[,9:10],col.line=c("orange","dark blue"),legend="topright")



