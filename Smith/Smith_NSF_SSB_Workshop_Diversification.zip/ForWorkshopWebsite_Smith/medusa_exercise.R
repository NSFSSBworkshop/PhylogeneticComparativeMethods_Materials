## Code by Stacey D. Smith, June 2015
## NSF-SSB workshop in Model-Based Phylogenetics
## example based on geiger documentation
## Feel free to download, distribute, edit and change the code as you see fit, however acknowledgment of the authors is expected. 


install.packages("ape")
install.packages("geiger")

library(geiger)
setwd("~/Desktop")
phy=read.tree("whales.tre") #load phylogeny, can enter plot(phy) to view
richness=read.csv("richness.csv", header=T) #numbers of species in each clade
phy
richness

res1=medusa(phy, richness, warnings=FALSE) #run medusa analysis
#Appropriate  aicc-threshold for a tree of 38 tips is: 2.09709.
# Step 1: lnLik=-128.2916; aicc=260.75; model=bd
# Step 2: lnLik=-119.9159; aicc=246.1699; shift at node 46; model=yule; cut=stem; # shifts=1
# No significant increase in aicc score. Disregarding subsequent piecewise models.
#  Model.ID Shift.Node Cut.At Model Ln.Lik.part         r epsilon     r.low   r.high
# 1        1         39   node  yule   -61.04221 0.0792518      NA 0.0580028 0.106650
# 2        2         46   stem  yule   -58.87372 0.2619390      NA 0.1736587 0.376152

plot(res1,cex=0.5, label.offset=1, edge.width=2) #visualize
