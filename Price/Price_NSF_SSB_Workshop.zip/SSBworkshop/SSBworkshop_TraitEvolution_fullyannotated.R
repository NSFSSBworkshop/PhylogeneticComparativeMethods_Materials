##########       Trait Evolution SSB Workshop Guaruja, Brazil 26th June 2015        ##########
#																																				  
# Today we have 90 minutes to cover both discrete and continuous trait evolution, so this will	  
# necessarily be brief. The goals are two-fold, to consolidate your understanding of the common
# models of trait evolution (continuous time Markov models for discrete traits as well as Ornstein
# Uhlenbeck and Brownian motion of continuous traits) and improve your knowledge of the		  
# implementations of these models in R to ask common evolutionary questions.						  
#																																			      
# Section 1) Discrete trait models and their implementation														  
# Section 2) Basic continuous trait models																				  
# Section 3) Combined continuous and discrete analyses														      
#		
# There is more information in this document than we can possibly cover but it will hopefully 
# it will be useful later when you are trying to implement these methods at home.								
# Author: Samantha Price (contact me if you have questions saprice 'at' ucdavis 'dot' edu)
#############################################################################

## PREPARATION
# load all the packages
library(ape)
library(geiger)
library(phytools)
library(corHMM)
library(OUwie)

# Read in the trees and data - we are assuming the working directory is the one where we have saved our tree and data

platydat<-read.table("platyrrhinedata.txt")

platytr<-read.nexus("platyrrhinetree.nex")

##############################################################################################
## SECTION 1: Discrete trait models and their implementation
#############################################################################################


# We model discrete traits using continuous time Markov models. As a quick reminder, at the heart of these models is the Q matrix which is the instantaneous rate matrix (with 3 states the Q matrix is 3x3) and it describes the 'instantaneous' rate of character change between each state. To get the rates of longer time periods you exponentiate the Q matrix times the length of the interval (e^-Qt) which in common Markov model notation is P(t). The probability of change from i to j states over interval t+dt: (Pij(t+dt))= (the probability i remains i over t (Pii) * rate for i to j over t (qij*dt)) + (probability that i goes to j over t (Pij(t)) * rate of staying in j ((1-qij)*dt))). 


# What questions can we ask with discrete traits? We can ask whether transitions between states occur at equal or different rates, allowing us to test for evolutionary dead-ends e.g. no transitions out of a particular state. We can test this by fitting different models with fitDiscrete in the geiger package, which may have been demonstrated by Josef Uyeda earlier. The simplest model we can fit is a single rates model. For example, if we have a trait with 3 states this means that the transitions from state1 to state2, state2 to state1, state3 to state2, state2 to state3, state1 to state3 and state3 to state2 all occur at the same rate (in R this is termed the ER (equal rates) model). However, there are various biological reasons that this might not make sense, for example it is probably harder to switch between herbivory and carnnivory than any of the others, we can test this by fitting a model which constrains the forward and back rates to be the same so that state1 to state2 = state2 to state1, state3 to state2 = state2 to state3 and state1 to state3 and state3 to state1 (in R this is terms the SYM (symmetric rates) model). We may also not want to constrain it to be symmetric for example, we may expect it to be much harder to enter state3 than it would to stop being in state 3 we could draw a Q matrix to reflect this precise expectation or we could say we want all the rates to be different (in R this is termed the ARD (all rates different) model).


## Put diet into a separate vector and name each element with the species

diet<-platydat$diet # put diet into a separate vector this is a simple binary trait herbivorous vs omnivorous
names(diet)<-row.names(platydat)

## Use the fitDiscrete function in geiger to see whether the transitions between dietary categories are best fit by a 1-rate (herbivore->omnivore = omnivore-> herbivore) or 2-rate model (herbivore->omnivore not = omnivore->herbivore)

dietER<-fitDiscrete(platytr, diet, model="ER")
#dietSYM<-fitDiscrete(platytr, diet, model="SYM") not necessary when only a binary model as SYM=ER
dietARD<-fitDiscrete(platytr, diet, model="ARD") 

# We can also estimate the ancestral history of a discrete trait, this usually isn't that informative on its own but can be very useful when trying to answer questions about whether the evolution of a continuous trait is infuenced by the state of a discrete trait. If you want to actually calculate the marginal likelihood of the ancestral states at each node you will need to use the rerooting method in phytools. However, as we are short on time we will focus today on stochastic character mapping, which is a Bayesian method (see Bollback 2006 and references therein). There are several reasons we may prefer this method 1) It allows changes on branches not just at nodes 2) It is not just a point estimate you can create multiple maps that display the uncertainty in the history of the character. This implements the method described by Nielsen 2002 Syst. Biol. 51, 729-739: a) It calculates the likelihood of each state at each node (i.e. does ML ancestral state reconstruction) b) Using these probabilities it then randomly samples a combination of ancestral states for each ancestral node c) then for each branch it simulates substitution history which if it is consistent with the state at the ancestral and daughter node then a single realization of the Markov process has been realized and the algorithm moves onto the next branch. This is all explained really clearly in Hulsenbeck 2003 Syst. Biol. 52, 131- 158.

# Note that this is a Bayesian method, so it requires priors on the transitions in Q, the precise nature of these priors varies depending on which implementation you use, either the stand-alone SIMMAP program written by Bollback or the make.simmap function in R (in phytools). Choosing priors can be tricky and so many people recommend using the most likely Q, which is the default in make.simmap but can be specified by Q="empirical". If you want to sample the posterior distribution of Q you would need to specify "mcmc" but it takes careful parameterization, as you can specify a different gamma distribution that describes each of the transitions if you like. If you want to specify specific priors I suggest you investigate Bollback's SIMMAP program. If you wish to take into account topological and branch length uncertainty (usually a good idea) you would run the maps across a sample of trees from the posterior distribution generated by BEAST, MrBayes etc. 


## Use stochastic character mapping implemented in the make.simmap function to estimate 9 possible histories of diet on the platyrrhine tree. Today we will be using the empirical estimate of Q as the prior using the best-fitting transition model and for the root state we will use the default, which is equal prior probabilities for each state at the root. Obviously in a proper analysis you would want to generate many trees (100's) and summarize over them.

 dietsimmap<-make.simmap(platytr, diet, model="ER",  Q="empirical", nsim=9)

## Plot all 9 character maps using a simple for loop to save time

par(mfrow=c(3,3)) # allow 9 things to be plotted in same window in a 3x3 matrix
for(i in 1:9) plotSimmap(dietsimmap[[i]], fsize=0)

## Estimate the posterior probability of each state at every node using the describe.simmap function. Note this only works if you are using the exact same tree topology (i.e. you aren't using a sample of trees) 

dietnodeprob<-describe.simmap(dietsimmap)
dietnodeprob$ace # these can be plotted as pie charts on the node etc.

## Write the stochastic maps to a file using write.simmap - note it only write a single map so you have to loop it or use lapply with append=T if you want them all written to the same file. 

for(i in 1:9) write.simmap(dietsimmap[[i]], file="platyrrhinedietsimmaps.nex", append=T)

# Note SIMMAPs are special tree objects so you can't just drop tips from the phylogeny using the ape functions you have already learnt about, but you can do it using drop.tip.simmap you can also re-order the edges using reorderSimmap and rescale it using rescaleSimmap.

# You will notice that for the stochastic mapping in R we still have to tell it which model to use i.e. if there is a bias in the transitions (SYM or ARD model) or not (ER model). However, it may be that several different constraints on the transition matrix can equally well explain the distribution of the trait upon the phylogeny, you can take this into account using a Reversible Jump MCMC approach as implemented in Mark Pagel & Andrew Meade's BayesTraits program (available from: http://www.evolution.rdg.ac.uk/BayesTraits.html). BayesTraits enables you to see the set of models with different rate constraints on the Q matrix that best fit your data and from it you can also calculate the ancestral state reconstruction and of course the model-averaged transition rates. In addition BayesTraits also allows you to use Maximum Likelihood and MCMC to estimate the ancestral states and rates. 

# So far all our methods have assumed that the transition rates are equal across the phylogeny, which may not be sensible if you are looking across very large clades. If you have a large tree and a binary trait you can use a hidden rates model developed by Jeremy Beaulieu and colleagues based on the covarion model of nucleotide substitution implemented in the corHMM package. This model allows different rate classes (up to 5). For example consider carnivorous or herbivorous mammals, you may have a fast and a slow rate so you can be HerbivoreSlow, CarnivoreSlow, HerbivoreFast and CarnivoreFast. However as you can't observe the rate you have to fix the probability of being either Fast or Slow to be 1, this means if we observe a herbivore at the tip then the probability for HerbivoreSlow and HerbivoreFast are both 1. Also this model assumes you have to change one trait first so you can't go from HerbivoreSlow to CarnivoreFast. This leads to a 4x4 Q matrix: 				  
#																					HS				CS				HF				CF
#																		HS        -				qHS->CS		qHS->HF		      0
#																		CS     qCS->HS          -                 0         	qCS->CF 
#																		HF     qHF->HS	       0				 -				qHF->CF	
#																		CF          0			qCF->CS		qCF->HF           -
#
# Biologically, this could mean that perhaps we are missing some subtlies in the data, for example carnivory can include those that eat insects and/or vertebrates and herbivory those that eat fruits and/or leaves. It may be much easier to switch in and out of frugivory and insectivory as they may not require as many tooth, gut and claw adaptations as folivory and vertebrate prey.

## Set up a dataset for corHMM where the first column contains the species names and the second the discrete trait, which in our case is diet. # This is quite a slow calculation and it is designed for large-datasets, so this is a toy example to show you how to implement it - we won't actually run this today.

hmmdiet<-cbind(row.names(platydat), platydat$diet) # first column must contain names and second diet 

## Use corHMM to fit rates constrained to be equal across the phylogeny (null)

hmmequal<-corHMM(platytr, hmmdiet, rate.cat=1, nstarts=10) # they recommend using plenty of different starting points to ensure ML has been reach but it takes along time so we are sticking with the low default of 10. Here we are fitting an equal rates model with a single rate class

## Use corHMM to fit a hidden-rates model that allows for transition rates to be unequal across the phylogeny - using a 4x4Q matrix with two rate classes

hmm2<-corHMM(platytr, hmmdiet, rate.cat=2, nstarts=10) # this fits a 4x4 Q matrix with two rate classes
# If we were to run this we would see the best-fitting model is the equal rates across the tree model which is not surprising given the few transitions in our dataset.

# Note you can also change the probability of the root state, the default assumes equal weighting of all possible states. You can also change how the ancestral states are estimated, the default is the marginal probabilities, other options are joint or scaled.

### CAUTION/ CAVEATS ### 
# The root state is very important for a lot of these models, for example if you have a low transition rate it will take a long time to get to the stationary distribution of the trait states and so for a long time it may look biased towards the root state. 
# A better question at this moment in time might be what questions can't I ask with discrete traits? Recent work has highlighted several shortcomings with methods focused on discrete traits (Maddison & Fitzjohn 2014; Rabosky & Goldberg 2015). We currently have no methods to ask whether a change in one discrete trait is dependent on the state of another discrete trait (correlation) or whether a change in one discrete trait influences the rate of net diversification. 

##############################################################################################
## SECTION 2: Basic continuous trait models - Brownian motion & Ornstein-Uhlenbeck
##############################################################################################


# The majority of phylogenetic comparative methods for continuous traits rely on Brownian motion as the model for evolution. Brownian motion: at each instant in time the state of a character can increase or decrease and the direction and magnitude of these changes are independent of current or past states (no trends etc.).  The total displacement of a character after time t is drawn from a normal distribtion with a mean of zero (i.e. net change in trait is 0) and a variance proportional to t. dX(t)= σ dB(t), X is the trait, σ is the Brownian motion rate, dB(t) is the trait change described by a normal distribution with a mean of 0.  

# To understand the Brownian motion we are going to learn how to simulate it. 

## First generate the displacements of the trait using the rnorm function to generate a normal distribution with a mean of zero for 100 units of time.

displace<-rnorm(100) 
plot(displace)

## The sum of these displacements represents the trajectory of the trait through time

x<-cumsum(displace)
plot(x, type="l", xlab="Time", ylab="Trait Value")

## Now plot 50 independent realizations of Brownian motion using a simple for loop to illustrate the relationship between time and variance
plot(cumsum(rnorm(100)), type="l", ylim=c(-30,30))
for(i in 1:49) lines(cumsum(rnorm(100)), col="cyan3") # simple for loop for each of the 49 samples we draw a line on the plot that is the cumulative summation of 100 draws from a normal distribution.  Here we can see variance in the trait is proportional to time 

## Repeat this plot but this time halve the standard deviation. The standard deviation of the normal distribution is related to the Brownian rate, we can illustate what happens when we decrease the rate by decreasing the SD (default SD=1)

plot(cumsum(rnorm(100)), type="l", ylim=c(-30,30), col="cyan3")
for(i in 1:49) lines(cumsum(rnorm(100)), col="cyan3") 
for(i in 1:50) lines(cumsum(rnorm(100, sd=0.5)), col="darkblue") 

## Obviously the above simulations were assuming the species were independent but we know that they are not, they share evolutionary history and this affects the evolution of their traits. Think about a 3 species tree:
library(ape)
tree<-read.tree(text="((GLTamarin:1, GHLTamarin:1):4, ETamarin:5);")
plot(tree)
axisPhylo()
nodelabels()

# Looking at this tree we see that GLTamarin and GHLTamarin share about 4 million years of history during which they all follow the same BM trajectory after which they split with both lineages starting on a new BM trajectory - we can simulate this. We need the branch length information: the longer the branch the greater the expected variance - with this we determine the standard deviation of the normal distribution. The total displacement of a character after time v is drawn from a normal distribtion with a mean of zero (i.e. net change in trait is 0) and a standard deviation = sqrt(rate*branchlength). 

## Lets assume we have a root state of 1 and a sigma^2 of 0.5 Start with the first branch from the root node 4 to 5 and estimate the trait value at node 5 and use the branch lengths to estimate the displacement.

x<-rnorm(1, mean=0, sd=sqrt(0.5*tree$edge.length[1]))

## Convert this displacement to a trajectory, so if the root state is 1 then you add the displacement to the root state to get the value at the node.

node5est<-1+x

# You then repeat this process across the tree calculating the displacement with sqrt(0.5*tree$edge.length[i]) and adding it to the ancestral node. Fortunately you don't need to be able to do this as there are many R functions that will do it for you such as fastBM in phytools.

# Note: simulation is a really important tool for 1) understanding the patterns generated by evolutionary models 2) helping you to determine if you have enough information within your dataset to fit various evolutionary models (i.e. power) and 3) estimating confidence intervals (see Boettiger et al. 2012). 

# Brownian motion (BM) is a special case of the Ornstein-Uhlenbeck (OU) model, which in its simplest case incorporates stabilizing selection around an adaptive primary optimum (θ), the variance around the peak is determined by the strength of pull towards the peak (α) and the stochastic variance of the (σ). dX(t)= α[θ -X(t)]dt+ σdB(t).  You can see that the strength of selection is proportional to the distance of the current trait value X(t) from the optimum – so sometimes alpha is called the rubber band parameter the more you stretch the more it wants to pull back to the middle. When α = 0 OU collapses to BM.  What is the primary optimum? It is a theoretical value, if multiple independent populations from same ancestor were allowed infinite time to evolve under the same selective regime it is the average adaptive optimum reached by these populations – it reflects the influence of the selective factor against a maximally randomized background. When α is stronger the more quickly the optima is reached and there is lower variance around the optima and when σ increases the variance around the optima also increases. So under a flexible OU model the variance in the trait is due to time and both σ & α, v=σ^2/2 α. It is important to recognize that alpha can also be thought of as a measure of the phylogenetic correlation - when it is high the correlation between closely related species is low. 

# Are α and σ identifiable? A decrease in σ and an increase in σ both reduce the variance of the rait at the tips of the tree so can you identify them both? Yes, theoretically an increase in α will erode the phylogenetic pattern but a decrease in σ will not. However there will be cases where various estimates of the two parameters are equally likely leading to a ridge in the likelihood surface. 

## Simulating data under a single-optimum Ornstein-Uhlenbeck (OU) model to understand how sigma and alpha influence the distribution of the trait at the tips. We are now going to simulate traits on the Platyrrhine tree using the simulation functions in the R package OUwie varying sigma and alpha and comparing the outcomes to Brownian motion. Note theta0 is the ancestral trait value the clade is evolving from we will assume theta0=theta for these simulations. First set up datasets in the OUwie format to indicate every species and every node belongs to the same regime/optimum. 

ouwiesimdat<-cbind(platytr$tip.label, rep(1, length((platytr$tip.label))))

platynodetr<-platytr
platynodetr$node.label<-rep(1, platynodetr$Nnode) # we need to add node labels to show which ancestral regime each node belongs to - with a single optima they are all the same

# run OUwie simulations with 1) Brownian motion sigma2=0.5; 2) OU theta = 1, sigma2=0.5, alpha=0.3; 3) OU theta = 1, sigma2=0.5, alpha=1; 4) OU theta = 1, sigma2=1, alpha=0.3, predict the rank of each of these simulations acording to their tip variance.

BM<- OUwie.sim(platynodetr, ouwiesimdat, simmap.tree=FALSE, alpha=1e-10, sigma.sq=0.5, theta0=1, theta=0)

OUtheta1sig0.5alph0.3 <- OUwie.sim(platynodetr, ouwiesimdat, simmap.tree=FALSE, alpha=0.3, sigma.sq=0.5, theta0=1, theta=1)

OUtheta1sig0.5alph1 <- OUwie.sim(platynodetr, ouwiesimdat, simmap.tree=FALSE, alpha=1, sigma.sq=0.5, theta0=1, theta=1)

OUtheta1sig1alph0.3 <- OUwie.sim(platynodetr, ouwiesimdat, simmap.tree=FALSE, alpha=0.3, sigma.sq=1, theta0=1, theta=1)

## Estimate the tip variance using the var function to see if your prediction was right.

var(BM[,3])
var(OUtheta1sig1alph0.3[,3])
var(OUtheta1sig0.5alph0.3[,3])
var(OUtheta1sig0.5alph1[,3])

## Plot phenograms/traitgrams to look at the inferred pattern of trait evolution over time - the phenogram function always works best if you put the phenotypic trait of interest into its own vector with species names.

BMvect<-BM[,3]
names(BMvect)<-BM[,1]
ousig1<-OUtheta1sig1alph0.3[,3]
names(ousig1)<-OUtheta1sig1alph0.3[,1]
oualph0.3<-OUtheta1sig0.5alph0.3[,3]
names(oualph0.3)<-OUtheta1sig0.5alph0.3[,1]
oualph1<-OUtheta1sig0.5alph1[,3]
names(oualph1)<-OUtheta1sig0.5alph1[,1]

par(mfrow=c(2,2))
phenogram(platynodetr, BMvect, fsize=0.01)
mtext("BM sig2=0.5", 3)
phenogram(platynodetr, ousig1, fsize=0.01)
mtext("OU sig2=1 alpha=0.3", 3)
phenogram(platynodetr, oualph0.3, fsize=0.01)
mtext("OU sig2=0.5 alpha0.3", 3)
phenogram(platynodetr, oualph1, fsize=0.01)
mtext("OU sig2=0.5 alpha=1", 3)

##############################################################################################
## SECTION 3: Combined continuous and discrete analyses				
##############################################################################################

#By combining continuous and discrete traits and OU/BM models we can start to answer some really interesting biological questions about state-dependent evolution of continuous traits. Depending on your data and your questions there are many different implementations that may be useful in R. If your response variables are inherently multivariate such as shape, as described by geometric morphometric x-y co-ordinates, then you will want to treat them as such and you should investigate the R packages mvSLOUCH (Bartoszek et al. 2012), mvMORPH (OU/BM) (Clavel et al. 2015) and geomorph (BM only) (Adams & Otarola-Castillo 2013). Today we will be using OUwie, which can take stochastically mapped trees or time slices and fit different OU models to each state/slice. So for example using the Platyrrhine data we can test the hypothesis that diet constrains body mass.

## Use phenograms to visualize the relationship between diet and bodymass 
logmass<- log10(platydat$AdultBodyMass_g) # putting the traits into a separate vector appears to stop some of the many plottings issues that can arise with phenograms
dietcol<-c("cyan3", "darkblue")
names(dietcol)<-c(1,2)
names(logmass)<-row.names(platydat)
phenogram(dietsimmap[[1]],logmass, colors=dietcol)


## Use OUwie to estimate the influence of diet on mass. So first set up a dataset in OUwie format where the first column contains the species names, the second column the discrete trait (diet) and the third column the continuous trait (log10 mass)

dat4ouwie<-data.frame(row.names(platydat), as.integer(platydat$diet), as.numeric(log10(platydat$AdultBodyMass_g))) # form dataset, it must have column entries in the following order: [,1] species names, [,2] current selective regime, and [,3] the continuous trait of interest. 

## Set up a vector to contain the names of all the models you want to run. For the sake of time and the fact that our dataset is small we are not fitting the more complex models so we will only fit single rate BM (BM1), multi-rate Brownian motion (BMS), single peak OU (OU1) and multi-peak OU (OUM) with the same alpha and sigma2

mods<-c("BM1", "BMS", "OU1", "OUM") 

## Now set up an empty matrix for the results from these four models with 14 columns and 4 rows

Ouwieres<-matrix(nrow=length(mods), ncol=14) # set up empty matrix for the results
colnames(Ouwieres)<-c("loglik", "AICc","alpha_1", "alpha_2", "alpha_1SE", "alpha_2SE", "sigma2_1", "sigma2_2", "sigma2_1SE", "sigma2_2SE", "theta_1", "theta_1SE", "theta_2", "theta_2SE")
rownames(Ouwieres)<-mods


## Now run a simple loop across the four models on the first stochastically mapped tree and extract the useful information

for(i in 1:length(mods)){ 
	tmp<-OUwie(dietsimmap[[1]], dat4ouwie, model=mods[[i]], simmap.tree=TRUE, root.station=TRUE, diagn=TRUE)
	Ouwieres[i,]<-c( tmp$loglik, tmp$AICc, tmp$solution[1,], tmp$solution.se[1,], tmp$solution[2,],tmp$solution.se[2,], tmp$theta[1,], tmp$theta[2,] )
}


# What are we doing when we set root.station=TRUE? We are stating whether the starting state, theta_0, should be estimated and the default is TRUE, which means theta_0 is dropped from the model so the starting value is distributed according to the stationary distribution of the OU process. Dropping theta_0 from the model can stabilize estimates of the primary optima, especially if you find the estimates of theta in the full model do not make sense biologically. However, this assumption does not fit a biological scenario involving moving away from an ancestral state. A good idea is to run preliminary analyses using both TRUE and FALSE to see which works for your dataset, for this one TRUE is best.

# What are we doing when we set diagn=TRUE? These models we are fitting are very complex and sometimes the information contained within the data are not sufficient and as a result one or more parameters may be estimated incorrectly. If you include the diagnostics in the OUwie run (diagn=T) it will include the eigendecomposition of the Hession matrix, which can indicate whether the maximum likelihood estimate has been found. If the eigenvalues of the Hessian are positive then parameter estimates are considered reliable (i.e. the Hessian is positive definite). However if it is not prohibitively slow you should estimate 95%CI of the parameter estimates from parametric bootstrapping using OUwie.boot rather than relying on the Hessian.

##  Which is the best-fitting model? Is there anything that might make you concerned about this choice?

Ouwieres

# Of course ideally want to run these analyses across a set of stochastically mapped trees to take into account the variability in the possible ancestral mapping of the discrete trait upon the tree. 

# If you want to identify shifts in θ or σ without looking for a relationship with a specific trait you can use:
# shifts in θ - bayou (Uyeda & Harmon 2014) or SURFACE R (Ingram & Mahler 2013) packages, the latter is specifically looking for convergence.
# shifts in σ - MotMot (multiple shifts)  (Thomas & Freckleton 2012) or phytools (single shift) (Revell 2012) R packages or BAMM (Raboksy 2014; Rabosky et al. 2014).


### CAUTION/CAVEATS ### 
#1) You need to be very careful when looping functions over trees that you don't misunderstand the structure of the output. For example, OUwie and Brownie.lite do not automatically sort their results to give the output for each state 1, 2, 3, instead it is determined by the stochastic character maps at the root, which is variable. This is why it is always a good idea to sort the results using the order function e.g [order(row.names(tmp$theta)),] etc. 
#2) OU models have some "interesting" behaviour and a bootstrapping approach to check for identifiability and power is highly recommended, additionally when identifying shifts most of the ways of determining the number of shifts will over estimate significantly (see Ho & Ane 2014 for further details).


##REFERENCES
#Adams, D.C., and E. Otarola-Castillo. 2013. geomorph: an R package for the collection and analysis of geometric morphometric shape data. Methods in Ecology and Evolution. 4:393-399.
#Bartoszek, K. and Pienaar, J. and Mostad. P. and Andersson, S. and Hansen, T. F. (2012) A phylogenetic comparative method for studying multivariate adaptation J. Theor. Biol. 314:204--215
#Beaulieu, J. M., Jhwueng, D. C., Boettiger, C., & O’Meara, B. C. (2012). Modeling stabilizing selection: expanding the Ornstein–Uhlenbeck model of adaptive evolution. Evolution, 66(8), 2369-2383.
#Beaulieu, J. M., O'Meara, B. C., & Donoghue, M. J. (2013). Identifying hidden rate changes in the evolution of a binary morphological character: the evolution of plant habit in campanulid angiosperms. Systematic biology, 62(5), 725-737.
#Boettiger, C., Coop, G., & Ralph, P. (2012). Is your phylogeny informative? Measuring the power of comparative methods. Evolution, 66(7), 2240-2251.
#Bollback, J. P. (2006). SIMMAP: stochastic character mapping of discrete traits on phylogenies. BMC bioinformatics, 7(1), 88.
#Clavel,J. with contributions from Aaron King and Emmanuel Paradis (2015). mvMORPH: Multivariate Comparative Tools for Fitting Evolutionary Models to Morphometric Data. R package version 1.0.5. http://CRAN.R-project.org/package=mvMORP
#Hansen, T. F. (1997). Stabilizing selection and the comparative analysis of adaptation. Evolution, 1341-1351.
#Harmon Luke J, Jason T Weir, Chad D Brock, Richard E Glor, and Wendell Challenger. 2008. GEIGER: investigating evolutionary radiations. Bioinformatics 24:129-131.
#Ho, L.S.T. & Ane, C. (2014) Intrinsic inference difficulties for trait evolution with Ornstein-Uhlenbeck models. Methods in Ecology & Evolution 5, 1133-1146.
#Huelsenbeck, J. P., Nielsen, R., & Bollback, J. P. (2003). Stochastic mapping of morphological characters. Systematic Biology, 52(2), 131-158.
#Ingram, T., & Mahler, D. L. (2013). SURFACE: detecting convergent evolution from comparative data by fitting Ornstein‐Uhlenbeck models with stepwise Akaike Information Criterion. Methods in Ecology and Evolution, 4(5), 416-425.
#Maddison, W. P., & FitzJohn, R. G. (2015). The unsolved challenge to phylogenetic correlation tests for categorical characters. Systematic biology, 64(1), 127-136.
#Nielsen, R. (2002). Mapping mutations on phylogenies. Systematic biology, 51(5), 729-739.
#O'Meara, B. C., Ané, C., Sanderson, M. J., & Wainwright, P. C. (2006). Testing for different rates of continuous trait evolution using likelihood. Evolution, 60(5), 922-933.
# Rabosky, D. L. (2014). Automatic detection of key innovations, rate shifts, and diversity-dependence on phylogenetic trees. PLoS One, 9(2), e89543.
# Rabosky, D. L., Grundler, M., Anderson, C., Shi, J. J., Brown, J. W., Huang, H., & Larson, J. G. (2014). BAMMtools: an R package for the analysis of evolutionary dynamics on phylogenetic trees. Methods in Ecology and Evolution, 5(7), 701-707.
#Rabosky, D. L., & Goldberg, E. E. (2015). Model inadequacy and mistaken inferences of trait-dependent speciation. Systematic biology, 64(2), 340-355.
#Revell, L. J. (2012) phytools: An R package for phylogenetic comparative biology (and other things). Methods Ecol. Evol. 3217-223 
#Thomas, G. H., & Freckleton, R. P. (2012). MOTMOT: models of trait macroevolution on trees. Methods in Ecology and Evolution, 3(1), 145-151.
#Uyeda, J. C., & Harmon, L. J. (2014). A novel Bayesian method for inferring and interpreting the dynamics of adaptive landscapes from phylogenetic comparative data. Systematic biology, 63(6), 902-918.


