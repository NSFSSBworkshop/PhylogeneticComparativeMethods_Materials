##########       Trait Evolution SSB Workshop Guaruja, Brazil 26th June 2015        #############################
#																																				  
# Today we have 90 minutes to cover both discrete and continuous trait evolution, so this will	  
# necessarily be brief. The goals are two-fold, to consolidate your understanding of the common
# models of trait evolution (continuous time Markov models for discrete traits as well as Ornstein
# Uhlenbeck and Brownian motion of continuous traits) and improve your knowledge of the		  
# implementations of these models in R to ask common evolutionary questions.						  
#																																			      
# Section 1) Discrete trait models and their implementation														  
# Section 2) Basic continuous trait models																				  
# Section 3) Combined continuous and discrete analyses														      
#		
# There is more information in this document than we can possibly cover but it will hopefully 
# it will be useful later when you are trying to implement these methods at home. The fully annotated
# version contains lots of additional information about the methods, implementations and other
# available software along with references.								
# Author: Samantha Price (contact me if you have questions saprice 'at' ucdavis 'dot' edu)
###############################################################################################

## PREPARATION
# load all the packages
library(ape)
library(geiger)
library(phytools)
library(corHMM)
library(OUwie)

# Read in the trees and data - we are assuming the working directory is the one where we have saved our tree and data

platydat<-read.table("platyrrhinedata.txt")

platytr<-read.nexus("platyrrhinetree.nex")

##############################################################################################
## SECTION 1: Discrete trait models and their implementation
#############################################################################################


## Put diet into a separate vector and name each element with the species

diet<-platydat$diet # put diet into a separate vector this is a simple binary trait herbivorous vs omnivorous
names(diet)<-row.names(platydat)

## Use the fitDiscrete function in geiger to see whether the transitions between dietary categories are best fit by a 1-rate (herbivore->omnivore = omnivore-> herbivore) or 2-rate model (herbivore->omnivore not = omnivore->herbivore)

dietER<-fitDiscrete(platytr, diet, model="ER")
#dietSYM<-fitDiscrete(platytr, diet, model="SYM") not necessary when only a binary model as SYM=ER
dietARD<-fitDiscrete(platytr, diet, model="ARD") 


## Use stochastic character mapping implemented in the make.simmap function to estimate 9 possible histories of diet on the platyrrhine tree. Today we will be using the empirical estimate of Q as the prior using the best-fitting transition model and for the root state we will use the default, which is equal prior probabilities for each state at the root. Obviously in a proper analysis you would want to generate many trees (100's) and summarize over them.

 dietsimmap<-make.simmap(platytr, diet, model="ER",  Q="empirical", nsim=9)

## Plot all 9 character maps using a simple for loop to save time

par(mfrow=c(3,3)) # allow 9 things to be plotted in same window in a 3x3 matrix
for(i in 1:9) plotSimmap(dietsimmap[[i]], fsize=0)

## Estimate the posterior probability of each state at every node using the describe.simmap function. Note this only works if you are using the exact same tree topology (i.e. you aren't using a sample of trees) 

dietnodeprob<-describe.simmap(dietsimmap)
dietnodeprob$ace # these can be plotted as pie charts on the node etc.

## Write the stochastic maps to a file using write.simmap - note it only write a single map so you have to loop it or use lapply with append=T if you want them all written to the same file. 

for(i in 1:9) write.simmap(dietsimmap[[i]], file="platyrrhinedietsimmaps.nex", append=T)

# Note SIMMAPs are special tree objects so you can't just drop tips from the phylogeny using the ape functions you have already learnt about, but you can do it using drop.tip.simmap you can also re-order the edges using reorderSimmap and rescale it using rescaleSimmap.


## Set up a dataset for corHMM where the first column contains the species names and the second the discrete trait, which in our case is diet. # This is quite a slow calculation and it is designed for large-datasets, so this is a toy example to show you how to implement it - we won't actually run this today.

hmmdiet<-cbind(row.names(platydat), platydat$diet) # first column must contain names and second diet 

## Use corHMM to fit rates constrained to be equal across the phylogeny (null)

hmmequal<-corHMM(platytr, hmmdiet, rate.cat=1, nstarts=10) # they recommend using plenty of different starting points to ensure ML has been reach but it takes along time so we are sticking with the low default of 10. Here we are fitting an equal rates model with a single rate class

## Use corHMM to fit a hidden-rates model that allows for transition rates to be unequal across the phylogeny - using a 4x4Q matrix with two rate classes

hmm2<-corHMM(platytr, hmmdiet, rate.cat=2, nstarts=10) # this fits a 4x4 Q matrix with two rate classes
# If we were to run this we would see the best-fitting model is the equal rates across the tree model which is not surprising given the few transitions in our dataset.

# Note you can also change the probability of the root state, the default assumes equal weighting of all possible states. You can also change how the ancestral states are estimated, the default is the marginal probabilities, other options are joint or scaled.

##############################################################################################
## SECTION 2: Basic continuous trait models - Brownian motion & Ornstein-Uhlenbeck
##############################################################################################


# To understand the Brownian motion we are going to learn how to simulate it. 

## First generate the displacements of the trait using the rnorm function to generate a normal distribution with a mean of zero for 100 units of time.

displace<-rnorm(100) 
plot(displace)

## The sum of these displacements represents the trajectory of the trait through time

x<-cumsum(displace)
plot(x, type="l", xlab="Time", ylab="Trait Value")

## Now plot 50 independent realizations of Brownian motion using a simple for loop to illustrate the relationship between time and variance
plot(cumsum(rnorm(100)), type="l", ylim=c(-30,30))
for(i in 1:49) lines(cumsum(rnorm(100)), col="cyan3") # simple for loop for each of the 49 samples we draw a line on the plot that is the cumulative summation of 100 draws from a normal distribution.  Here we can see variance in the trait is proportional to time 

## Repeat this plot but this time halve the standard deviation. The standard deviation of the normal distribution is related to the Brownian rate, we can illustate what happens when we decrease the rate by decreasing the SD (default SD=1)

plot(cumsum(rnorm(100)), type="l", ylim=c(-30,30), col="cyan3")
for(i in 1:49) lines(cumsum(rnorm(100)), col="cyan3") 
for(i in 1:50) lines(cumsum(rnorm(100, sd=0.5)), col="darkblue") 

## Obviously the above simulations were assuming the species were independent but we know that they are not, they share evolutionary history and this affects the evolution of their traits. Think about a 3 species tree:
tree<-read.tree(text="((GLTamarin:1, GHLTamarin:1):4, ETamarin:5);")
plot(tree)
axisPhylo()
nodelabels()


## Lets assume we have a root state of 1 and a sigma^2 of 0.5 Start with the first branch from the root node 4 to 5 and estimate the trait value at node 5 and use the branch lengths to estimate the displacement.The total displacement of a character after time v is drawn from a normal distribtion with a mean of zero (i.e. net change in trait is 0) and a standard deviation = sqrt(rate*branchlength). 

x<-rnorm(1, mean=0, sd=sqrt(0.5*tree$edge.length[1]))

## Convert this displacement to a trajectory, so if the root state is 1 then you add the displacement to the root state to get the value at the node.

node5est<-1+x

# You then repeat this process across the tree calculating the displacement with sqrt(0.5*tree$edge.length[i]) and adding it to the ancestral node. Fortunately you don't need to be able to do this as there are many R functions that will do it for you such as fastBM in phytools.


## Simulating data under a single-optimum Ornstein-Uhlenbeck (OU) model to understand how sigma and alpha influence the distribution of the trait at the tips. We are now going to simulate traits on the Platyrrhine tree using the simulation functions in the R package OUwie varying sigma and alpha and comparing the outcomes to Brownian motion. Note theta0 is the ancestral trait value the clade is evolving from we will assume theta0=theta for these simulations. First set up datasets in the OUwie format to indicate every species and every node belongs to the same regime/optimum. 

ouwiesimdat<-cbind(platytr$tip.label, rep(1, length((platytr$tip.label))))

platynodetr<-platytr
platynodetr$node.label<-rep(1, platynodetr$Nnode) # we need to add node labels to show which ancestral regime each node belongs to - with a single optima they are all the same.

# run OUwie simulations with 1) Brownian motion sigma2=0.5; 2) OU theta = 1, sigma2=0.5, alpha=0.3; 3) OU theta = 1, sigma2=0.5, alpha=1; 4) OU theta = 1, sigma2=1, alpha=0.3, predict the rank of each of these simulations acording to their tip variance.

BM<- OUwie.sim(platynodetr, ouwiesimdat, simmap.tree=FALSE, alpha=1e-10, sigma.sq=0.5, theta0=1, theta=0)

OUtheta1sig0.5alph0.3 <- OUwie.sim(platynodetr, ouwiesimdat, simmap.tree=FALSE, alpha=0.3, sigma.sq=0.5, theta0=1, theta=1)

OUtheta1sig0.5alph1 <- OUwie.sim(platynodetr, ouwiesimdat, simmap.tree=FALSE, alpha=1, sigma.sq=0.5, theta0=1, theta=1)

OUtheta1sig1alph0.3 <- OUwie.sim(platynodetr, ouwiesimdat, simmap.tree=FALSE, alpha=0.3, sigma.sq=1, theta0=1, theta=1)

## Estimate the tip variance using the var function to see if your prediction was right.

var(BM[,3])
var(OUtheta1sig1alph0.3[,3])
var(OUtheta1sig0.5alph0.3[,3])
var(OUtheta1sig0.5alph1[,3])

## Plot phenograms/traitgrams to look at the inferred pattern of trait evolution over time - the phenogram function always works best if you put the phenotypic trait of interest into its own vector with species names.

BMvect<-BM[,3]
names(BMvect)<-BM[,1]
ousig1<-OUtheta1sig1alph0.3[,3]
names(ousig1)<-OUtheta1sig1alph0.3[,1]
oualph0.3<-OUtheta1sig0.5alph0.3[,3]
names(oualph0.3)<-OUtheta1sig0.5alph0.3[,1]
oualph1<-OUtheta1sig0.5alph1[,3]
names(oualph1)<-OUtheta1sig0.5alph1[,1]

par(mfrow=c(2,2))
phenogram(platynodetr, BMvect, fsize=0.01)
mtext("BM sig2=0.5", 3)
phenogram(platynodetr, ousig1, fsize=0.01)
mtext("OU sig2=1 alpha=0.3", 3)
phenogram(platynodetr, oualph0.3, fsize=0.01)
mtext("OU sig2=0.5 alpha0.3", 3)
phenogram(platynodetr, oualph1, fsize=0.01)
mtext("OU sig2=0.5 alpha=1", 3)

##############################################################################################
## SECTION 3: Combined continuous and discrete analyses				
##############################################################################################

#By combining continuous and discrete traits and OU/BM models we can start to answer some really interesting biological questions about state-dependent evolution of continuous traits. Today we will be using OUwie, which can take stochastically mapped trees or time slices and fit different OU models to each state/slice. So for example using the Platyrrhine data we can test the hypothesis that diet constrains body mass.

## Use phenograms to visualize the relationship between diet and bodymass 
logmass<- log10(platydat$AdultBodyMass_g) # putting the traits into a separate vector appears to stop some of the many plottings issues that can arise with phenograms
dietcol<-c("cyan3", "darkblue")
names(dietcol)<-c(1,2)
names(logmass)<-row.names(platydat)
phenogram(dietsimmap[[1]],logmass, colors=dietcol)


## Use OUwie to estimate the influence of diet on mass. So first set up a dataset in OUwie format where the first column contains the species names, the second column the discrete trait (diet) and the third column the continuous trait (log10 mass)

dat4ouwie<-data.frame(row.names(platydat), as.integer(platydat$diet), as.numeric(log10(platydat$AdultBodyMass_g))) # form dataset, it must have column entries in the following order: [,1] species names, [,2] current selective regime, and [,3] the continuous trait of interest. 

## Set up a vector to contain the names of all the models you want to run. For the sake of time and the fact that our dataset is small we are not fitting the more complex models so we will only fit single rate BM (BM1), multi-rate Brownian motion (BMS), single peak OU (OU1) and multi-peak OU (OUM) with the same alpha and sigma2

mods<-c("BM1", "BMS", "OU1", "OUM") 

## Now set up an empty matrix for the results from these four models with 14 columns and 4 rows

Ouwieres<-matrix(nrow=length(mods), ncol=14) # set up empty matrix for the results
colnames(Ouwieres)<-c("loglik", "AICc","alpha_1", "alpha_2", "alpha_1SE", "alpha_2SE", "sigma2_1", "sigma2_2", "sigma2_1SE", "sigma2_2SE", "theta_1", "theta_1SE", "theta_2", "theta_2SE")
rownames(Ouwieres)<-mods


## Now run a simple loop across the four models on the first stochastically mapped tree and extract the useful information

for(i in 1:length(mods)){ 
	tmp<-OUwie(dietsimmap[[1]], dat4ouwie, model=mods[[i]], simmap.tree=TRUE, root.station=TRUE, diagn=TRUE)
	Ouwieres[i,]<-c( tmp$loglik, tmp$AICc, tmp$solution[1,], tmp$solution.se[1,], tmp$solution[2,],tmp$solution.se[2,], tmp$theta[1,], tmp$theta[2,] )
}

##  Which is the best-fitting model? Is there anything that might make you concerned about this choice? What are your options for checking these results?

Ouwieres




